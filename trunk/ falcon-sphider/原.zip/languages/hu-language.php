<?php 
$sph_messages =  Array (
	"Categories" => "Kateg�ri�k",
	"CATEGORIES" => "KATEG�RI�K",
	"Untitled" => "Untitled document",
	"Powered by" => "T�mogatja a",
	"Previous" => "El�z�",
	"Next" => "K�vetkez�",
	"Result page" => "Eredm�nyek",
	"Only in category" => "Csak ebben a kateg�ri�ban",
	"Search" => "Keres�s",
	"All sites" => "Minden oldal",
	"Web pages" => "Weblapok",
	"noMatch" => "A keres�snek \"%query\" nem volt eredm�nye",
	"ignoredWords" => "A k�vetkez� szavakat hagytam figyelmen k�v�l (t�l r�vid vagy �ltal�nos): %ignored_words",
	"resultsFor" => "Eredm�nyek:",
	"Results" => "Eredm�nyek list�z�sa %from - %to ennyib�l: %all %matchword (%secs mp)", //
	"match" => "egyez�s",     //
	"matches" => "egyez�s", //
	"andSearch" => "�S keres�s",         
	"orSearch" => "VAGY keres�s",    
	"phraseSearch" => "Kifejez�s keres�se",
	"show" => "Mutass ",
	"resultsPerPage" => "ennyit egy oldalon",
	"DidYouMean" => "Did you mean"
);
?>